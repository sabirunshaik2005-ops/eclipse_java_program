package cse;

import java.util.Arrays;

public class justcode {
public static void main(String[] args) {
	int [] a= {0,1,0,1,1,0,1};
	
	for(int i=0;i<a.length-1;i++)
	{
		for(int j=0;j<a.length-i-1;j++)
		{
			if(a[j]>a[j+1])
			{
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	System.out.println("order:"+Arrays.toString(a));

}
}
