package cse;

import java.util.Arrays;
import java.util.Scanner;

public class reverse {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	int n=s.nextInt();
	int [] a=new int[n];
	int N[]=Arrays.copyOf(a,a.length);
	System.out.println("arrays copy of:"+Arrays.toString(N));
	for(int i=0;i<10;i++)
	{
		a[i]=s.nextInt();
	}
	for(int i=n-1;i>=0;i--)
	{
	System.out.println("reverse of array"+Arrays.toString(N));
}
s.close();
}
}